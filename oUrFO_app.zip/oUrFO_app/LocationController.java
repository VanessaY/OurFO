/**
 * Created by lilliankuhn on 10/26/17.
 */


import com.sun.org.apache.xpath.internal.operations.Mod;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.geometry.*;

import java.util.ArrayList;


public class LocationController {

    private ComboBox<String> planet = new ComboBox<>();
    private ComboBox<String> station = new ComboBox<>();
    private String plan = "";
    private int planID = 0;
    private int stat = 0;

    private Button selectPlanet(){
        Button find = new Button("Select Planet");

        find.setOnAction(e -> {
            try{

                plan = planet.getValue();
                planID = Model.getPlanetID(plan);

                initStations(planID);
                Model.trip.setStartPlanet(planID);


            }
            catch(Exception exc){
                System.out.println(exc.getMessage());
            }
        });

        return find;
    }

    private Button selectStation(){
        Button find = new Button("Select Station");

        find.setOnAction(e -> {
            try{

                stat = Integer.parseInt(station.getValue());

                Model.trip.setStartStation(stat);


                Main.setPane(3);
                ChooseAndGoController.initShips();
            }
            catch(Exception exc){
                System.out.println(exc.getMessage());
            }
        });

        return find;
    }


    private void initPlanets(){

        ArrayList planets = Model.listPlanets();

        planet.getItems().addAll(planets);
    }




    private void initStations(int planet){

        ArrayList stations = Model.listStationsOnPlanet(planet);

        station.getItems().addAll(stations);

    }

    private Button backButton(){

        Button back = new Button("Back");

        back.setOnAction( e -> {
            Main.setPane(0);
        });

        return back;
    }

    public VBox buildLocationScreen(){
        VBox screen = new VBox();
        screen.setAlignment(Pos.CENTER);
        screen.setPadding(new Insets(10,10,10,10));
        screen.setSpacing(10);

        initPlanets();
        initStations(planID);

        screen.getChildren().addAll(new Label( "Tell me where you are!"),
                new Label("Location: "), planet, selectPlanet(),
                new Label("Station: "), station, selectStation(),
                backButton());

        return screen;
    }
}
