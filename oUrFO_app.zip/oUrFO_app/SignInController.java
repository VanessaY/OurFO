

import javafx.scene.layout.*;
import javafx.geometry.*;
import javafx.scene.control.*;


public class SignInController {

    private TextField username = new TextField();

    private Button SignInButton(){
        Button signIn = new Button("Sign In");
        signIn.setOnAction(e -> {
            try{

                    String uname = username.getText();

                    int alienID = Model.getAlienID(uname);



                    if( alienID == 0) {
                        username.clear();
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Input error");
                        alert.setHeaderText(null);
                        alert.setContentText("Enter valid username.");

                        alert.showAndWait();
                    }else{
                        Model.trip.setAlien(alienID);

                        Main.setPane(2);
                    }


            }
            catch(Exception exc){
                System.out.println(exc.getMessage());
            }

        });
        return signIn;
    }

    private Button RegisterButton(){
        Button register = new Button("Register");
        register.setOnAction(e -> {

            Main.setPane(1);

        });
        return register;
    }

    public VBox buildSignInScreen(){

        VBox screen = new VBox();
        screen.setAlignment(Pos.CENTER);
        screen.setPadding(new Insets(10,10,10,10));
        screen.setSpacing(10);

        HBox userName = new HBox();

        userName.getChildren().add(new Label("Username: "));
        userName.getChildren().add(username);




        screen.getChildren().addAll( userName,  SignInButton(), RegisterButton());

        return screen;

    }

}
