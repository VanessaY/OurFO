import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

import java.util.ArrayList;

/**
 * Created by lilliankuhn on 11/30/17.
 */
public class DestinationController {


    // maybe these are textfields instead and we find nearest ships?
    private ComboBox<String> planet = new ComboBox<>();
    private ComboBox<String> station = new ComboBox<>();
    private String plan = "";
    private int planID = 0;
    private int stat = 0;

    private Button selectPlanet(){
        Button find = new Button("Select Planet");

        find.setOnAction(e -> {
            try{

                plan = planet.getValue();
                planID = Model.getPlanetID(plan);
                initStations(planID);

                Model.trip.setEndPlanet(planID);

                Main.setPane(3);
            }
            catch(Exception exc){
                System.out.println(exc.getMessage());
            }
        });

        return find;
    }

    private Button selectStation(){
        Button find = new Button("Select Station");

        find.setOnAction(e -> {
            try{

                stat = Integer.parseInt(station.getValue());

                Model.trip.setEndStation(stat);

                Main.setPane(4);

            }
            catch(Exception exc){
                System.out.println(exc.getMessage());
            }
        });

        return find;
    }

    private void initPlanets(){

        ArrayList planets = Model.listPlanets();

        planet.getItems().addAll(planets);
    }




    private void initStations(int planet){

        ArrayList stations = Model.listStationsOnPlanet(planet);

        station.getItems().addAll(stations);

    }

    private Button backButton(){

        Button back = new Button("Back");

        back.setOnAction( e -> {
            Main.setPane(2);
        });

        return back;
    }

    public VBox buildDestinationScreen(){
        VBox screen = new VBox();
        screen.setAlignment(Pos.CENTER);
        screen.setPadding(new Insets(10,10,10,10));
        screen.setSpacing(10);

        initPlanets();
        initStations(planID);

        screen.getChildren().addAll(new Label( "Tell me where you are going!"),
                new Label("Location: "), planet, selectPlanet(),
                new Label("Station: "), station, selectStation(),
                 backButton());

        return screen;
    }
}
