/**
 * Created by lilliankuhn on 10/26/17.
 */


import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;


public class ReviewController {


    private ComboBox<String> stars = new ComboBox();


    private Button arriveButton(){
        Button arrive = new Button("Arrived");

        arrive.setOnAction(e -> {

            Model.dockShip( Model.trip.getEndStation(), Model.trip.getShip());

        });

        return arrive;
    }

    private Button rateCurrPlanetButton(){
        Button rate = new Button("Rate this planet!");

        rate.setOnAction(e -> {
            try{

                int rating = getStars(stars.getValue());

                if( rating == -1) {

                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Input error");
                    alert.setHeaderText(null);
                    alert.setContentText("How many stars?");

                    alert.showAndWait();
                }else{

                    Model.ratePlanet( rating,  Model.trip.getAlien(), Model.trip.getEndPlanet());

                }


            }
            catch(Exception exc){
                System.out.println(exc.getMessage());
            }
        });

        return rate;
    }

    private Button rateFromPlanetButton(){
        Button rate = new Button("Rate the planet you just left!");

        rate.setOnAction(e -> {
            try{

                int rating = getStars(stars.getValue());
                if( rating == -1) {

                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Input error");
                    alert.setHeaderText(null);
                    alert.setContentText("How many stars?");

                    alert.showAndWait();
                }else{
                    Model.ratePlanet( rating,  Model.trip.getAlien(), Model.trip.getStartPlanet());

                }



            }
            catch(Exception exc){
                System.out.println(exc.getMessage());
            }
        });

        return rate;
    }

    private Button rateShipButton(){
        Button rate = new Button("Rate your ship");

        rate.setOnAction(e -> {
            try{

                int rating = getStars(stars.getValue());
                if( rating == -1) {

                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Input error");
                    alert.setHeaderText(null);
                    alert.setContentText("How many stars?");

                    alert.showAndWait();
                }else{
                    Model.rateShip( rating, Model.trip.getAlien(), Model.trip.getShip());

                }


            }
            catch(Exception exc){
                System.out.println(exc.getMessage());
            }
        });

        return rate;
    }

	private Button backButton(){
		Button back = new Button("Back");
		back.setOnAction( e -> {
			Main.setPane(3);
		});
	
		return back;
	}
    private void initStars(){
        stars.getItems().addAll("5 --  Out of this world",
                                        "4 -- Stellar",
                                        "3 -- ...ok",
                                        "2 -- Eh",
                                        "1 -- Gross");
    }

    private int getStars(String mssg){

        switch (mssg){
            case "5 --  Out of this world" : return 5;
            case "4 -- Stellar" : return 4;
            case "3 -- ...ok" : return 3;
            case "2 -- Eh" : return 2;
            case "1 -- Gross" : return 1;

            default: return -1;
        }

    }

    public VBox buildReviewScreen(){
        VBox screen = new VBox();
        screen.setAlignment(Pos.CENTER);
        screen.setSpacing(10);
        screen.setPadding(new Insets(10,10,10,10));

        initStars();

        screen.getChildren().addAll(arriveButton(), stars, rateShipButton(), rateFromPlanetButton(),
                rateCurrPlanetButton(), backButton());


        return screen;
    }

}
