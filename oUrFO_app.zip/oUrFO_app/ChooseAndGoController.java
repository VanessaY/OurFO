/**
 * Created by lilliankuhn on 10/26/17.
 */


import com.sun.org.apache.xpath.internal.operations.Mod;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.geometry.*;

import javax.jws.WebParam;
import java.util.ArrayList;


public class ChooseAndGoController {

    private static ComboBox<String> ships = new ComboBox<>();


    private Button goButton(){
        Button go = new Button("GO!");
        go.setOnAction(e -> {

            String ship = ships.getValue();
            int shipID = Model.getShipID(ship);

            Model.trip.setStartStation(shipID);

            Model.dockShip( -1, shipID);

            Main.setPane(5);
        });

        return go;
    }

	private Button backButton(){
		
		Button back = new Button("Back");
		back.setOnAction(e -> {
			Main.setPane(2);
		});

		return back;
	}


    public static void initShips(){

        System.out.println(Model.trip.getStartStation());
        System.out.println(Model.listShipsAtStation());

        ArrayList UFOs = Model.listShipsAtStation();

        ships.getItems().addAll(UFOs);

    }

    public VBox buildGoScreen(){
        VBox screen = new VBox();
        screen.setPadding(new Insets(10,10,10,10));
        screen.setAlignment(Pos.CENTER);
        screen.setSpacing(10);

        initShips();

        screen.getChildren().addAll(new Label("Choose ship"), ships, goButton(), backButton());

        return screen;
    }
}
