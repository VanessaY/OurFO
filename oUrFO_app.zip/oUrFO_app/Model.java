/**
 *
 * initiates connection to DB and communicates with the View/Controllers
 *
 * Created by lilliankuhn on 11/29/17.
 */

import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Model {

    public static Connection connection = null;
    public static Trip trip = new Trip();

    public Model() {

        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("PostgreSQL JDBC Driver not found");
            e.printStackTrace();
            return;
        }


        String username = "p32003a";


        String password = "changeTHISplease";


        try {
            connection = DriverManager.getConnection(
                    "jdbc:postgresql://reddwarf.cs.rit.edu:5432/p32003a", username,
                    password);
        } catch (SQLException e) {
            System.out.println("Connection Failed! Check output console");
            e.printStackTrace();
            return;
        }

        if (connection == null) {
            System.out.println("Failed to make connection!");
            System.exit(0);
        }
    }

    public void exit(Connection c) {
        try {
            c.close();
            System.out.println("Connection closed!");
            System.exit(0);
        } catch (SQLException e) {
            System.out.println("Could not close connection!");
            e.printStackTrace();
            System.exit(0);
        }

    }

    public static int getShipID(String ship){

        Scanner sc = new Scanner(ship);
        return sc.nextInt();
    }

    // grabs user.id from name
    // returns 0 if user not found
    public static int getAlienID(String name){
        int id = 0;

        try {
            Statement st = connection.createStatement();
            String query = "SELECT id FROM \"User\" WHERE username = \'" + name + "\'";
            ResultSet rs = st.executeQuery(query);

            rs.next();
            id = Integer.parseInt(rs.getString(1));

            System.out.println(id);

        }catch (SQLException e) {
            System.out.println(e);
        }

        return id;
    }

    public static int getPlanetID(String planet){
        int id = 0;

        try {
            Statement st = connection.createStatement();
            String query = "SELECT id FROM planet WHERE name = \'" + planet + "\'";
            ResultSet rs = st.executeQuery(query);

            rs.next();
            id = Integer.parseInt(rs.getString(1));

        }catch (SQLException e) {
            System.out.println(e);
        }

        return id;
    }

    public static ArrayList listPlanets(){
        ArrayList planets = new ArrayList();

        try{

            Statement st = connection.createStatement();
            String query = "SELECT name FROM planet";

            ResultSet rs = st.executeQuery(query);

            while(rs.next()){
                planets.add(rs.getString(1));
            }

        }catch (SQLException e){
            System.out.println(e);
        }


        return planets;
    }

    public static ArrayList listStationsOnPlanet(int planet){
        ArrayList stations = new ArrayList();

        try{

            Statement st = connection.createStatement();
            String query = "SELECT location FROM station WHERE planet_id = " + planet;

            ResultSet rs = st.executeQuery(query);

            while(rs.next()){
                stations.add(rs.getString(1));
            }

        }catch (SQLException e){
            System.out.println(e);
        }


        return stations;
    }

    public static ArrayList listShipsAtStation(){
        ArrayList stations = new ArrayList();

        try{

            Statement st = connection.createStatement();
            String query =  "SELECT ship.id, ship_models.name FROM " +
                    "ship natural JOIN ship_models WHERE ship.dockedAt = " + trip.getStartStation();
            ResultSet rs = st.executeQuery(query);

            while(rs.next()){
                stations.add(rs.getString(1)+ " " +rs.getString(2));
            }

        }catch (SQLException e){
            System.out.println(e);
        }


        return stations;
    }

    public static ArrayList listSpecies(){
        ArrayList spList = new ArrayList();

        try{

            Statement st = connection.createStatement();
            String query = "SELECT name FROM species";

            ResultSet rs = st.executeQuery(query);

            while(rs.next()){
                spList.add(rs.getString(1));
            }

        }catch (SQLException e){
            System.out.println(e);
        }

        return spList;
    }

    public static void addUser(String u_name, String type){

        int spID = 0;

        try {
            // find species id
            Statement st = connection.createStatement();
            String query = "SELECT id FROM species WHERE species.name = \'" + type + "\'";
            ResultSet rs = st.executeQuery(query);
            rs.next();
            spID = Integer.parseInt(rs.getString(1));


            Statement s = connection.createStatement();
            String stmt = String.format("INSERT INTO \"User\" (username, species_id) VALUES (\'%s\', \'%d\')",
                    u_name, spID);
            System.out.println(stmt);

            PreparedStatement p = connection.prepareStatement(stmt);
            p.executeUpdate();
        } catch (SQLException e){
            System.out.println(e);
        }

    }


    // set dockedAt to new station
    public static void dockShip(int station, int shipID){


        try {
            // set to null if in flight
            if( station == -1){
                Statement st = connection.createStatement();
                String query = String.format("UPDATE ship SET dockedAt = null WHERE id = \'%d\'",  shipID);
                ResultSet rs = st.executeQuery(query);
                rs.next();
            }
            else {
                // set dockedAt
//                Statement stmt;
//                stmt = connection.prepareStatement("UPDATE ship SET dockedAt = ? WHERE ship.id = ?");
//                stmt.setInt(1, station);
//                stmt.setInt(2, shipID);
//                stmt.executeUpdate();
                Statement st = connection.createStatement();
                String query = "UPDATE ship SET dockedAt = " + station + " WHERE id = " + shipID;
                ResultSet rs = st.executeQuery(query);
                rs.next();
            }

        } catch (SQLException e){
            System.out.println(e);
        }
    }

    public static void rateShip( int rating, int uID, int shipID){

        try {

            Statement st = connection.createStatement();
            String query = String.format("INSERT INTO ship_review ( rating, rating_time" +
                    "written_by, written_for) VALUES  %d, CURRENT_TIMESTAMP, \'%d\', \'%d\'",
                    rating, uID, shipID);
            ResultSet rs = st.executeQuery(query);
            rs.next();

        } catch (SQLException e){
            System.out.println(e);
        }
    }

    public static void ratePlanet( int rating, int uID, int planetID){
        try {

            Statement st = connection.createStatement();
            String query = String.format("INSERT INTO planet_review ( rating, rating_time" +
                            "written_by, written_for) VALUES  %d, CURRENT_TIMESTAMP, \'%d\', \'%d\'",
                    rating, uID, planetID);
            ResultSet rs = st.executeQuery(query);
            rs.next();

        } catch (SQLException e){
            System.out.println(e);
        }
    }

}
