/**
 *
 * Object to hold trip data
 *
 * Created by lilliankuhn on 11/30/17.
 */
public class Trip {

    private int ship = 0;
    private int alien = 0;
    private int startPlanet = 0;
    private int startStation = 0;
    private int endPlanet = 0;
    private int endStation = 0;

    public int getAlien() {
        return alien;
    }

    public void setAlien(int alien) {
        this.alien = alien;
    }

    public int getStartPlanet() {
        return startPlanet;
    }

    public void setStartPlanet(int startPlanet) {
        this.startPlanet = startPlanet;
    }

    public int getStartStation() {
        return startStation;
    }

    public void setStartStation(int startStation) {
        this.startStation = startStation;
    }

    public int getEndPlanet() {
        return endPlanet;
    }

    public void setEndPlanet(int endPlanet) {
        this.endPlanet = endPlanet;
    }

    public int getEndStation() {
        return endStation;
    }

    public void setEndStation(int endStation) {
        this.endStation = endStation;
    }

    public int getShip() {
        return ship;
    }

    public void setShip(int ship) {
        this.ship = ship;
    }
}
