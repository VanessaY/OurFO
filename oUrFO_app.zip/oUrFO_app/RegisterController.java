/**
 * Created by lilliankuhn on 10/26/17.
 */

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.*;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;


import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class RegisterController {


    private TextField username = new TextField();
    private ComboBox<String> species = new ComboBox<>();

    //private TextField password = new TextField();
    //private TextField home = new TextField();


    private Button registerButton(){
        Button register = new Button("Register");
        register.setOnAction(e -> {
            try {

                String user = username.getText();
                String type = species.getValue();

                Model.addUser(user, type);
                Model.trip.setAlien(Model.getAlienID(user));

                Main.setPane(2);
            }
            catch(Exception exc){
                    System.out.println(exc.getMessage());
                }

        });
        return register;
    }

	private Button backButton(){

		Button back = new Button("Back");
		back.setOnAction( e -> {
			Main.setPane(0);
		});
		return back;
	}

    private void initSpecies(){

        ArrayList spList = Model.listSpecies();


        species.getItems().addAll(spList);
    }

    public VBox buildRegisterScreen(){
        VBox screen = new VBox();
        screen.setAlignment(Pos.CENTER);
        screen.setSpacing(10);
        screen.setPadding(new Insets(10,10,10,10));

        GridPane userInfo = new GridPane();
        userInfo.setHgap(10);
        userInfo.setVgap(10);
        initSpecies();

        userInfo.add(new Label("Username: "), 0, 0);
        userInfo.add(username, 1, 0);
        //userInfo.add(new Label("Password: "), 0, 1);
        //userInfo.add(password, 1, 1);
        userInfo.add(new Label("Species: "), 0,2);
        userInfo.add(species,1,2);

        screen.getChildren().addAll(userInfo, registerButton(), backButton());

        return screen;

    }
}
